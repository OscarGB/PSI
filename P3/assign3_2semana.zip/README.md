## Practica 3 PSI - Semana 2
## Pareja 4
 - Aitor Arnaiz del Val
 - Óscar Gómez Borzdynski
 
